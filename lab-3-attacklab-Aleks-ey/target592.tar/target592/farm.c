/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_484(unsigned *p)
{
    *p = 3347662959U;
}

unsigned addval_231(unsigned x)
{
    return x + 3281031256U;
}

void setval_198(unsigned *p)
{
    *p = 3267856712U;
}

void setval_330(unsigned *p)
{
    *p = 3284638024U;
}

unsigned addval_208(unsigned x)
{
    return x + 2438516513U;
}

void setval_181(unsigned *p)
{
    *p = 2425393240U;
}

unsigned addval_282(unsigned x)
{
    return x + 2425393232U;
}

unsigned getval_468()
{
    return 3347663068U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_223(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_460()
{
    return 2463009241U;
}

unsigned getval_148()
{
    return 3281178249U;
}

unsigned getval_331()
{
    return 2464188744U;
}

unsigned addval_174(unsigned x)
{
    return x + 3223376265U;
}

unsigned getval_338()
{
    return 3353381192U;
}

unsigned addval_346(unsigned x)
{
    return x + 3229139593U;
}

void setval_153(unsigned *p)
{
    *p = 3348156809U;
}

unsigned addval_218(unsigned x)
{
    return x + 3281306249U;
}

unsigned addval_296(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_157()
{
    return 3685008009U;
}

unsigned addval_189(unsigned x)
{
    return x + 3281047177U;
}

unsigned getval_286()
{
    return 2464188744U;
}

unsigned addval_310(unsigned x)
{
    return x + 3286272320U;
}

unsigned addval_459(unsigned x)
{
    return x + 3525366153U;
}

unsigned addval_408(unsigned x)
{
    return x + 2429649199U;
}

unsigned addval_368(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_396(unsigned x)
{
    return x + 3353381192U;
}

void setval_131(unsigned *p)
{
    *p = 3230978441U;
}

unsigned getval_147()
{
    return 3375419785U;
}

void setval_440(unsigned *p)
{
    *p = 2428668298U;
}

void setval_352(unsigned *p)
{
    *p = 3523792521U;
}

void setval_447(unsigned *p)
{
    *p = 3281306249U;
}

unsigned getval_354()
{
    return 3531919769U;
}

unsigned addval_364(unsigned x)
{
    return x + 2425671305U;
}

unsigned addval_405(unsigned x)
{
    return x + 2425409163U;
}

unsigned getval_409()
{
    return 3380924040U;
}

void setval_442(unsigned *p)
{
    *p = 3229926017U;
}

unsigned addval_351(unsigned x)
{
    return x + 3525362305U;
}

void setval_199(unsigned *p)
{
    *p = 3223372425U;
}

unsigned getval_434()
{
    return 3247493513U;
}

void setval_467(unsigned *p)
{
    *p = 3372797576U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
